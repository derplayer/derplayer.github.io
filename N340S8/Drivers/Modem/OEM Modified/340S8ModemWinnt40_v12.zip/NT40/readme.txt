Smart Link 56K Modem Driver

Version: 2.84

(C) 1998-2000 Smart Link Ltd.
=============================

This document contains release notes and other information about 
this product. Information in this document is the most current 
available. For your convenience, print a copy of this file and 
keep it with your user manual. 

------------------------
How to Use This Document
------------------------
To view README.TXT on screen in Windows Notepad, maximize the 
Notepad window.

To print README.TXT, open it in Windows Write, Microsoft Word, 
or another word processor.  Then select the entire document and 
format the text in 10-point Courier before printing.

This file (README.TXT) contains:

--------
Contents
--------
1) Installation
2) How to verify installation
3) Uninstall procedure
4) Update procedure
5) Country Selection
6) Call Progress Sounds
7) Known issues
8) Troubleshooting


--------------
1. Installation
--------------

Important notes:

   1) This driver supports HAMR5600, SmartRiseer56 and SmartPCI56 modem 
      chipsets.

   2) For HAMR5600 and SmartRiser56, this driver is compatible with 
      motherboards based on the Intel 810, 820, 815E, 820E, 440MX (Banister), 
      VIA VT82C686, SiS 540 / 630 and ALI M1535/M1535D+ core logic chipsets. 
      An updated list of compatible motherboards can be found on Smart Link's 
      web site (www.smlink.com).

   3) This version of drivers is compatible only with Microsoft 
      Windows NT 4.0.

   4) If a Smart Link modem is already installed in your system and you want 
      to update its' device driver, first uninstall existing drivers (See 
      Uninstall Procedure), and only then proceed to install the new drivers.

   5) Before installing, check your HAMR5600 or SmartRiser56 card for proper 
	 setting of Primary or Secondary Codec Mode.



To install your modem drivers for the first time:
-------------------------------------------------

Note: Windows NT 4.0 is not a Plug and Play operating system in 
the extent featured in Windows 95/98. This single fact is the cause 
for much confusion with OEM's who are most familiar with 
Windows 98/95. The Installation process for the modem is the same 
as for Programs.

a) Open the installation folder or CD-ROM, and double-click on the
   "Setup.exe" icon. Follow the instructions on the screen.

b) When requested, replace the installation disks according to the 
   instructions on the screen.

c) You must choose a Communication Port which will be used for 
   your modem. It is recommended to choose Port with number 3 or 4 
   because some old applications (16-bit) do not support a port higher 
   then COM4.

d) After files are copied, you will be asked to continue installation 
   by standard Modem Installer.

e) Click the "Next" button.
   Because the modem is not yet installed, it can't be detected by the 
   System. We recommend you to check "Do not detect my modem..."	and 
   select a modem from the list.

f) Choose Manufacturer and Model from the list and press Next button.

   Your Manufacturer is "Modem Vendor", Model is "Smart Link 56K Modem".

g) Select your desired Communication Port. 

h) Reboot your computer.

The Modem setup is now finished.

NOTE: if Remote Access Service (RAS) is installed on your 
computer, Windows NT will ask you to reconfigure Dial-Up 
Network for the new Modem. You must do it according to your 
Internet Service Provider Recommendations.


-----------------------------
2. How to verify installation
-----------------------------

To verify that the modem is installed correctly, follow these steps:

 a) In Control Panel - Modems: check for the presence of your modem.


To Check that the modem is working properly:

 a) Run HyperTerminal.
 b) Selct the modem or "Direct to port" option.
 c) Type ATI1, ATI2 or ATI3 and make sure you receive the modem IDs. 
 d) Dial any accessible phone number, and see that that phone rings.
 e) Dial to another modem (ATDTxxx or via the dial button of the     
    TAPI interface) and see that a modem session is established.

    If you have successfully connected, then the modem has been     
    successfully installed.


----------------------
3. Uninstall Procedure
----------------------
a) Open "Control Panel > Modems" folder and choose 
	"Smart Link 56K Modem".

b) Click the "Remove" button.

c) Open the "Control Panel > Add/Remove Programs" folder
   and choose "Smart Link 56K Modem".

d) Click the "Add/Remove" button.

e) Modem drivers will now be removed.

f) Reboot your computer.



-------------------
4. Update Procedure
-------------------

To update your modem drivers, uninstall previous drivers 
(see above procedure) and reboot your system.

Then repeat the Installation process, as described in the 
above procedure.


--------------------
5. Country Selection
--------------------

NOTE: THIS FEATURE IS SUPPORTED ONLY WITH INTERNATIONAL VERSIONS OF DRIVERS
AND NOT WITH USA DRIVERS.

To change the country setting, follow these steps:

a) Click "Start > Settings > Control Panel > Modem Country Selection"
b) Select required country from the list
c) Click "Ok" 


To verify the change has taken effect:

a) Open HyperTerminal and select your modem
b) Type "ATI7"
c) Verify that the correct country name is displayed


-----------------------
6. Call Progress Sounds
-----------------------

Riser card modems designs typically support three methods 
for monitoring call progress (dialtone, DTMF dialing, etc...). 
The method you should use depends on your specific hardware:

(a) In hardware through AC-Link:
	* Simply connect speakers to the AC97 audio speaker
        output
      * Then enable and unmute "Telephone" or "Phone in"
        in the Playback audio mixer  from the speaker icon
        that appears in the mixer tray

(b) In hardware directly through the sound card:
	* Connect the 4 pin header on the modem card to the
        TAM header on the audio card/subsytem.

(c) In hardware using the optional buzzer that may be present
	on the modem card:
	* Nothing needs to be done to hear this. It is always on.
	  You can control the buzzer volume from the 
	  Control Panel/Modem/Properties/Speaker Volume.


---------------
7. Known issues
---------------

7.1 	When using the following applications/online services, select the 
	appropriate modem name from the following modem list:
	* AOL (America Online) - "Hayes Compatible (Default)" 
	* Juno - "Generic 33600 modem". 
	* BitWare - "Rockwell based voice modem"

7.2  On certain motherboards, call progress can be heard through the system's 
	speakers. This option is enabled by default, and can be controlled only from
	Windows' "Volume Control" application, using the "Telephony" slider.
	The 'Speaker' menu option (accessed by right-clicking on the modem icon) 
	can not mute the modem sound on these motherboards.

7.3 	Trying to install the modem using the "Have disk" button will not 
	work. The modem will not appear in the list of available devices. 
	The only valid way to install the modem is using it's Setup program.


------------------
8. Troubleshooting
------------------

If your modem does not work as expected:

8.1	If ERROR, NO DIALTONE or a similar message is received:

	(a)   Check whether the line is connected preperly to the modem.
	(b)   Use a telephone handset to make sure that the line is
	      active and that there is a dial tone.
	(c)   Check to see if the line is a PBX line or a direct analog
              phone line. You may need to dial 9, before the actual 
	      desired telephone number (i.e. ATDT9,123-4567).
	      If, after dialing 9, the modem still cannot detect the PBX
	      dialtone, try typing ATX3 before dialing.

		NOTE that PBX lines typically can only support V.34
		rates (33,600 bps, 28,800 bps, ...) and NOT V.90
		rates (49,333 bps, 50,666 bps, ...).


8.2	If dialer application (i.e. Hyperterminal) does not detect modem:

	(a)   Check whether HyperTerminal is configured to the right port.
	      You can find the modem's COM port number in 
 	      "Control Panel > Modems > Properties". 
	      If not, press disconnect and change the port that the dialer 
	      is accessing.


8.3	If you cannot hear the dialtone and DTMF dialing while the modem should
	be dialing out:

       Riser card modems hardware designs typically support three methods 
       for monitoring call progress (dialtone, DTMF dialing, etc...). 
       The method you should use depends on your specific hardware:

       (a) In hardware through AC-Link:
       	* Simply connect speakers to the AC97 audio speaker
               output
             * Then enable and unmute "Telephone" or "Phone in"
               in the Playback audio mixer  from the speaker icon
               that appears in the mixer tray

       (b) In hardware directly through the sound card:
       	* Connect the 4 pin header on the modem card to the
               TAM header on the audio card/subsytem.

       (c) In hardware using the optional buzzer that may be present 
		on the modem card:
       	* Nothing needs to be done to hear this. It is always on.
       	  You can control the buzzer volume from the 
       	  Control Panel/Modem/Properties/Speaker Volume.

--------------------
All trademarks are property of their respective owners.